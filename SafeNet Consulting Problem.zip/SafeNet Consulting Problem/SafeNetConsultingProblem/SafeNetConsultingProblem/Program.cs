﻿using System;

namespace SafeNetConsultingProblem
{
    class ATM
    {
        private int[] money = { 10, 10, 10, 10, 10, 10 };
        private int[] denominations = { 100, 50, 20, 10, 5, 1 };
        public ATM()
        {
        }
        public void Balance()
        {
            Console.WriteLine("Machine balance: ");
            for (int i = 0; i < money.Length; i++)
            {
                Console.WriteLine("$" + denominations[i] + ": " + money[i]);
            }
        }
        public void Restock()
        {
            for (int i = 0; i < money.Length; i++)
            {
                money[i] = 10;
            }
            Balance();
        }
        public void Withdraw(string amount)
        {
            int n = Int32.Parse(amount.Substring(amount.IndexOf('$') + 1));
            Boolean stop = false;
            int count = 0;
            int n1 = n;
            while (count < denominations.Length)
            {
                if (money[count] < (n1 / denominations[count]))
                {
                    stop = true;
                }
                n1 -= (n1 / denominations[count]) * denominations[count];
                count++;
            }
            if (!stop)
            {
                Console.WriteLine("Success: dispensed $" + n);
                for (int i = 0; i < money.Length; i++)
                {
                    money[i] -= (n / denominations[i]);
                    n -= (n / denominations[i]) * denominations[i];
                }
                Balance();
            }
            else
            {
                Console.WriteLine("Failure: insufficient funds");
            }
        }
        public void Inquiry(string input)
        {
            string[] amounts = input.Split("$");
            int[] intAmounts = new int[amounts.Length - 1];
            for (int i = 1; i < amounts.Length; i++)
            {
                intAmounts[i - 1] = Int32.Parse(amounts[i]);
            }
            for (int j = 0; j < intAmounts.Length; j++)
            {
                for (int k = 0; k < denominations.Length; k++)
                {
                    if (intAmounts[j] == denominations[k])
                    {

                        Console.WriteLine("$" + denominations[k] + ": " + money[k]);
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            ATM machine = new ATM();
            Boolean stop = false;
            while (!stop)
            {
                Console.WriteLine("Enter in 'I<denominations>' for inquiry, 'W<dollar amount>' to withdraw, 'R' to restock the ATM, and 'Q' to quit.");
                string input = Console.ReadLine();
                char s = input[0];

                switch (s)
                {
                    case 'R':
                        machine.Restock();
                        break;
                    case 'W':
                        machine.Withdraw(input);
                        break;
                    case 'I':
                        machine.Inquiry(input);
                        break;
                    case 'Q':
                        stop = true;
                        break;
                    default:
                        Console.WriteLine("Failure: invalid command");
                        break;
                }
            }
        }
    }
}
